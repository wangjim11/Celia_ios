//
//  ViewController.h
//  External-Audio-Device
//
//  Copyright (c) 2014 TokBox Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end

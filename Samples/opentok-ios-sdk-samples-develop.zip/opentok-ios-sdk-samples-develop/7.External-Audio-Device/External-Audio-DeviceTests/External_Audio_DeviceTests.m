//
//  External_Audio_DeviceTests.m
//  External-Audio-DeviceTests
//
//  Created by Steve McFarlin on 7/7/14.
//  Copyright (c) 2014 TokBox Inc. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface External_Audio_DeviceTests : XCTestCase

@end

@implementation External_Audio_DeviceTests

- (void)setUp
{
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown
{
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end

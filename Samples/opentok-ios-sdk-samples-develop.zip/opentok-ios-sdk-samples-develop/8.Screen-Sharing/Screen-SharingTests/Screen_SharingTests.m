//
//  Screen_SharingTests.m
//  Screen-SharingTests
//
//  Created by Steve McFarlin on 8/27/14.
//  Copyright (c) 2014 TokBox Inc. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface Screen_SharingTests : XCTestCase

@end

@implementation Screen_SharingTests

- (void)setUp
{
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown
{
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end

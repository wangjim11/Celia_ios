//
//  TBAudioLevelMeter.h
//  TestAudioMeter
//
//  Created by Sridhar on 02/06/14.
//  Copyright (c) 2014 Tokbox. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TBAudioLevelMeter : UIView
{
    
}
@property(assign, nonatomic) CGFloat level;
@property(assign, nonatomic) UIView* toucesPassToView;
@end

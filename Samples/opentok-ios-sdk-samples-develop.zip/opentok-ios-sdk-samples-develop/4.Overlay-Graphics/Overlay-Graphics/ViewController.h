//
//  ViewController.h
//  Overlay-Graphics
//
//  Created by Sridhar on 28/02/14.
//  Copyright (c) 2014 Tokbox. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <OpenTok/OpenTok.h>

@interface ViewController : UIViewController <OTSubscriberKitAudioLevelDelegate>
{
    
}

@end
